package visao;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controle.ControUsuario;


public class VisaoUsuario extends JFrame {
	
	

	public VisaoUsuario  ( ControUsuario controlador){
		
		
		setTitle("Cadastro de Contato");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		
		JLabel labelNome = new JLabel("Nome: ");
		JLabel labelTelefone = new JLabel ("Telefone: ");
		JLabel labelEndereco = new JLabel ("Endereco: ");
		JLabel labelEmail = new JLabel ("Email: ");
		
		
		JTextField textNome = new JTextField(60);
		JTextField textTelefone = new JTextField(15);
		JTextField textEndereco = new JTextField(50);
		JTextField textEmail = new JTextField(30);
		
		JButton botaoCadastrar = new JButton("Cadastro");
		JButton botaoCancelar = new JButton("Cancelar");
		
		
		JPanel painel = new JPanel();
		
		ActionListener listenerCadastrar = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				String nome = textNome.getText();
				String telefone = textTelefone.getText();
				String email = textEmail.getText();
				String endereco = textEndereco.getText();
				
				controlador.cadastrarUsuario(nome, telefone, email, endereco); 
				
				
			}
		};
		botaoCadastrar.addActionListener(listenerCadastrar);
		
		ActionListener listenerCancelar = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				dispose();
			}
		};
		
		botaoCancelar.addActionListener(listenerCancelar);
		
		painel.add(labelNome);
		painel.add(textNome);
		
		painel.add(labelTelefone);
		painel.add(textTelefone);
		
		painel.add(labelEndereco);
		painel.add(textEndereco);
		
		painel.add(labelEmail);
		painel.add(textEmail);
		
		painel.add(botaoCadastrar);
		painel.add(botaoCancelar);
		
		
		add(painel);
		
		pack();
		
		
		
	}	

}
