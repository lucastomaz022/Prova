package modelo.Dao;

	import java.io.BufferedInputStream;
	import java.io.DataOutputStream;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.io.InputStream;

	import javax.swing.JOptionPane;



	public class UsuarioDao {
		
		public void gravarArquivo(String caminho, String conteudo) {
			
			try {
				
				DataOutputStream saida = new DataOutputStream(
						new FileOutputStream(caminho));
				
				byte[] bytes = conteudo.getBytes();
				
				saida.write(bytes);
				
				saida.flush();
				saida.close();
				
			} catch (FileNotFoundException e) {
				JOptionPane.showMessageDialog(null, 
						"Arquivo ou diret�rio n�o encontrado!");
				e.printStackTrace();
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, 
						"Problemas ao gravar arquivo.");
				e.printStackTrace();
			}
			
		}
		
		public void lerArquivo(String caminho) {
		
			try {
				
				InputStream entrada = new BufferedInputStream(
						new FileInputStream(caminho));
				
				int dado;
				String conteudo = "";
				
				while((dado = entrada.read()) != -1) {
					conteudo += (char) dado;
					System.out.println(dado);
				}
				
				entrada.close();
				
				JOptionPane.showMessageDialog(null, conteudo);
				
			} catch (FileNotFoundException e) {
				JOptionPane.showMessageDialog(null, 
						"Arquivo ou diret�rio n�o encontrado!");
				e.printStackTrace();
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, 
						"Problemas ao ler arquivo.");
				e.printStackTrace();
			}
			
		}


}
