package controle;

import modelo.Usuario;




public class ControUsuario {
	
	
	public void cadastrarUsuario  (String nome,  String telefone, String email, 
			 String endereco) {
		
		
		Usuario c = new Usuario();
		
		c.setNome(nome);
		c.setEndereco(endereco);
		c.setTelefone(telefone);
		c.setEmail(email);		
	
			
	
	}

}
