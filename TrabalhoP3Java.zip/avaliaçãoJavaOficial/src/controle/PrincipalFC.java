package controle;

	import javax.swing.JOptionPane;

import modelo.Dao.UsuarioDao;

import visao.VisaoUsuario;


	public class PrincipalFC{

		public static void main(String[] args) {
			
			UsuarioDao manipulador = new UsuarioDao ();
			
			ControUsuario controlador= new  ControUsuario();
			
			VisaoUsuario tela = new VisaoUsuario (controlador);
			
			tela.setVisible(true);
								
			String conteudo = JOptionPane.showInputDialog(controlador);
			
			String caminho = "C:\\Aluno\\arquivo_stream.meuArquivo";
			
			manipulador.gravarArquivo(caminho, conteudo);
			manipulador.lerArquivo(caminho);
				
		}

	}


	
	

